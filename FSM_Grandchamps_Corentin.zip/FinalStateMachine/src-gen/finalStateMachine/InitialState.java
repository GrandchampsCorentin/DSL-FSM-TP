/**
 */
package finalStateMachine;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see finalStateMachine.FinalStateMachinePackage#getInitialState()
 * @model
 * @generated
 */
public interface InitialState extends State {
} // InitialState
