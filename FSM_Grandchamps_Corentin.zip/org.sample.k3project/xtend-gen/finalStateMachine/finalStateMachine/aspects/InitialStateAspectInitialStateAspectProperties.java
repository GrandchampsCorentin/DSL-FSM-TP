package finalStateMachine.finalStateMachine.aspects;

@SuppressWarnings("all")
public class InitialStateAspectInitialStateAspectProperties {
}
