package finalStateMachine.finalStateMachine.aspects;

import finalStateMachine.State;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;

@Aspect(className = State.class)
@SuppressWarnings("all")
public class StateAspect {
}
