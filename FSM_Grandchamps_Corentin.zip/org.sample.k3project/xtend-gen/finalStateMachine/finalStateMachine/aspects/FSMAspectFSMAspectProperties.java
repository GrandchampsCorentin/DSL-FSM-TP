package finalStateMachine.finalStateMachine.aspects;

import finalStateMachine.State;

@SuppressWarnings("all")
public class FSMAspectFSMAspectProperties {
  public State currentState;
  
  public State finalState;
}
