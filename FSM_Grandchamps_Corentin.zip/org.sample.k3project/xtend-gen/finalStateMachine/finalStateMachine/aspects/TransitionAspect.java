package finalStateMachine.finalStateMachine.aspects;

import finalStateMachine.Transition;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;

@Aspect(className = Transition.class)
@SuppressWarnings("all")
public class TransitionAspect {
}
